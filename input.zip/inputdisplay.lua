--[[============================================================================
  Input Display - training pause menu toggle
  Drop this file in:  external/mods/inputdisplay.lua   (auto-loaded at startup)

  Adds an "Input Display" ON/OFF item to the BOTTOM of the Training pause menu,
  built exactly like the stock options (Dummy Control, Guard Mode, etc.) using
  the engine's sanctioned append helper (main.f_appendItemname) and the same
  value-cycling helper (menu.f_valueChanged) the other items use.

  The chosen state is written to a global engine map key, '_iksys_inputDisplayP1',
  so the in-match renderer (Common.Lua side) can read it every frame.
============================================================================--]]

local menu = require('menu')

-- 1) Value options shown when cycling the item (Disabled / Enabled).
--    displaynames come from the motif so they can be themed/translated;
--    the 'or' fallbacks keep it working even if the motif keys are absent.
local m = motif.pause_menu.training_pause_menu.menu
menu.t_valuename.inputdisplay = {
	{itemname = 'disabled', displayname = (m.valuename and m.valuename.inputdisplay_disabled) or 'Disabled'},
	{itemname = 'enabled',  displayname = (m.valuename and m.valuename.inputdisplay_enabled)  or 'Enabled'},
}

-- remembered selection index for this session (1 = disabled, 2 = enabled)
menu.inputdisplay = menu.inputdisplay or 1

-- 2) Behaviour when the value is changed - mirror the stock training handlers,
--    but instead of an engine training-map we set our own flag that the
--    renderer reads. player(1) so the flag rides on P1.
menu.t_itemname['inputdisplay'] = function(t, item, cursorPosY, moveTxt, sec)
	if menu.f_valueChanged(t.items[item], sec) then
		player(1)
		mapSet('_iksys_inputDisplayP1', menu.inputdisplay - 1) -- 0 = off, 1 = on
	end
	return true
end

-- 3) Put the item on screen at the BOTTOM of the training pause menu.
--    No 'before' argument => appended after the existing items.
main.f_appendItemname(
	m,
	'',
	'inputdisplay',
	(m.itemname and m.itemname.inputdisplay) or 'Input Display'
)
