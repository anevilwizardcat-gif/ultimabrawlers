--[[============================================================================
  Input Display - per-frame renderer (Common.Lua side)
  Place this file anywhere readable (e.g. external/script/) and register it in
  your config's Common.Lua list so it runs during matches. In config.json:

      "Common": {
          "Lua": [ ... existing entries ... ,
                   "external/script/inputdisplay_common.lua" ]
      }

  HOW IT RUNS: Ikemen executes every Common.Lua file's contents once PER FRAME
  via DoString on the shared Lua state. So globals persist between frames; we do
  heavy setup once (guarded by the INPUTDISP global) and the read+draw every frame.

  Shows P1's inputs on the left as a scrolling list (oldest on top, newest on the
  bottom). Identical consecutive inputs collapse into one row with a frame count,
  exactly like a standard fighting-game input reader. Toggled on/off by the
  "Input Display" item added to the Training pause menu (external/mods/inputdisplay.lua),
  which writes the flag to P1's map key '_iksys_inputDisplayP1'.
============================================================================--]]

-- ---- one-time setup (persists across frames on the shared Lua state) ----
if INPUTDISP == nil then
	INPUTDISP = {}
	local d = INPUTDISP

	-- A command list we feed P1's input into each frame. Each entry is a
	-- "key is held" command ('/' prefix), so commandGetState is true while held.
	d.cl = commandNew()
	commandAdd(d.cl, 'U', '/U', 1, 1)
	commandAdd(d.cl, 'D', '/D', 1, 1)
	commandAdd(d.cl, 'B', '/B', 1, 1)
	commandAdd(d.cl, 'F', '/F', 1, 1)
	commandAdd(d.cl, 'a', '/a', 1, 1)
	commandAdd(d.cl, 'b', '/b', 1, 1)
	commandAdd(d.cl, 'c', '/c', 1, 1)
	commandAdd(d.cl, 'x', '/x', 1, 1)
	commandAdd(d.cl, 'y', '/y', 1, 1)
	commandAdd(d.cl, 'z', '/z', 1, 1)

	-- Reusable text object + a full-charset menu font (numbers for directions,
	-- letters for buttons).
	d.fnt = fontNew('ikemen1/fonts/Menu2Small.def')
	d.txt = textImgNew()
	textImgSetFont(d.txt, d.fnt)
	textImgSetScale(d.txt, 0.5, 0.5)

	d.hist = {}      -- [1]=oldest ... [#]=newest
	d.MAX  = 16      -- visible rows
	d.btnOrder = {'a','b','c','x','y','z'}
end

local d = INPUTDISP

-- Feed P1's input into the command list this frame (must run every frame,
-- even when hidden, so the buffer stays current the instant it's switched on).
commandInput(d.cl, 1)

-- On/off flag from the training-menu toggle (written to P1's map).
player(1)
if (map('_iksys_inputDisplayP1') or 0) == 0 then
	return -- hidden: nothing to draw this frame
end

-- ---- read this frame's held directions -> numpad notation ----
local U = commandGetState(d.cl, 'U')
local D = commandGetState(d.cl, 'D')
local B = commandGetState(d.cl, 'B')
local F = commandGetState(d.cl, 'F')
local dir
if     U and F then dir = 9
elseif U and B then dir = 7
elseif U        then dir = 8
elseif D and F then dir = 3
elseif D and B then dir = 1
elseif D        then dir = 2
elseif F        then dir = 6
elseif B        then dir = 4
else                dir = 5 end

-- ---- read this frame's held buttons ----
local btns = ''
for _, k in ipairs(d.btnOrder) do
	if commandGetState(d.cl, k) then btns = btns .. k end
end

-- ---- collapse repeats, else push a new row (the "scroll") ----
local key = tostring(dir) .. btns
local n = #d.hist
if n > 0 and d.hist[n].key == key then
	if d.hist[n].frames < 99 then d.hist[n].frames = d.hist[n].frames + 1 end
else
	d.hist[#d.hist + 1] = {key = key, dir = dir, btns = btns, frames = 1}
	if #d.hist > d.MAX then table.remove(d.hist, 1) end
end

-- ---- draw (320x240 base coords; left edge, newest at the bottom) ----
local x, baseY, rowH = 6, 40, 11
fillRect(x - 3, baseY - 3, 80, d.MAX * rowH + 4, 0, 0, 0, 140, 255) -- backing panel
for i = 1, #d.hist do
	local e = d.hist[i]
	local s = tostring(e.dir)
	if e.btns ~= '' then s = s .. ' ' .. e.btns:upper() end
	s = s .. '  ' .. e.frames
	textImgSetText(d.txt, s)
	textImgSetPos(d.txt, x, baseY + (i - 1) * rowH)
	textImgDraw(d.txt)
end
