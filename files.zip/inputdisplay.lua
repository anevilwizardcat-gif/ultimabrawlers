--[[============================================================================
  Input Display - training pause menu toggle
  Location:  external/mods/inputdisplay.lua   (auto-loaded at startup)

  ARCHITECTURE NOTE: in this engine `menu`, `main`, and `motif` are GLOBAL tables
  that main.lua has already populated by the time mods load (main.lua does
  `menu = require('external.script.menu')` earlier, assigned to a GLOBAL). A
  module must USE those globals directly and must NOT re-require them. Everything
  below is guarded so a missing global quietly no-ops instead of crashing at boot.
============================================================================--]]

if menu ~= nil and type(menu.t_valuename) == 'table' and type(menu.t_itemname) == 'table' then

	-- Value options (literal strings: no motif dependency, and avoids the
	-- "key already exists" early-out in main.f_appendItemname).
	menu.t_valuename.inputdisplay = {
		{itemname = 'disabled', displayname = 'Disabled'},
		{itemname = 'enabled',  displayname = 'Enabled'},
	}
	menu.inputdisplay = menu.inputdisplay or 1 -- 1 = disabled, 2 = enabled

	-- On change: cycle the value (same helper the stock items use) and write the
	-- flag to P1's map so the in-match renderer can read it.
	menu.t_itemname['inputdisplay'] = function(t, item, cursorPosY, moveTxt, sec)
		if menu.f_valueChanged(t.items[item], sec) then
			player(1)
			mapSet('_iksys_inputDisplayP1', menu.inputdisplay - 1) -- 0 = off, 1 = on
		end
		return true
	end

	-- Append the item to the BOTTOM of the training pause menu via the engine's
	-- sanctioned helper (adds it to the itemname table and its order list).
	local tmenu = motif and motif.pause_menu and motif.pause_menu.training_pause_menu
		and motif.pause_menu.training_pause_menu.menu
	if tmenu ~= nil and main ~= nil and type(main.f_appendItemname) == 'function' then
		main.f_appendItemname(tmenu, '', 'inputdisplay', 'Input Display')
	end

end
