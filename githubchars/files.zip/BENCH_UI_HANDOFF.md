# ULTIMABRAWLERS — BENCH UI PROTOCOL & PROJECT HANDOFF
*For future Claude: read this fully before touching anything. It encodes weeks of trial-and-error.*
*User: Raven. Solo dev, Ikemen GO 2v2 tag fangame. Last updated: 2026-06-11.*

---

## 1. WHO/WHAT/WHERE

- **Game**: Ikemen GO nightly (2026.06 build), native tag (data/tag.zss in States list — a MODIFIED non-release lineage). 2v2 tag. All chars localcoord 320x240. Windows.
- **Repo (the ONLY way Raven passes files; uploads roll off / chat may not accept uploads)**:
  `https://github.com/anevilwizardcat-gif/ultimabrawlers`
  Raw base: `https://raw.githubusercontent.com/anevilwizardcat-gif/ultimabrawlers/main/`
  - Chars: `/githubchars/<folder>/` — FOLDER & FILE CASING IS CHAOTIC. Probe variants when 404 (e.g. `Cvs_iori` but `cvskyo`; `jedah` lowercase but `Morrigan` capital; iori's system file is `Cvs2_system.cns` capital C).
  - Engine files: `/other/` (config.ini, fight.def, common1.cns.zss, select.def, tag.zss, common.const).
  - Raven can also commit screenshots to repo root for Claude to view (worked: curl the raw jpg, then `view` it — THE single most informative debugging step of the whole project; measured the lifebar sprite-axis offset from one image).
- **Config facts**: LifeShare=0, PowerShare=1, Tag.LoseOnKO=0. GitHub API rate-limited; raw fetches always work.
- **Tag states (other/common.const)**: EnteringScreen=6565600, LeavingScreen=6565610, WaitingOutside=6565611, JumpingIn=6565620, Landing=6565621. **Bench test everywhere = `stateno = [6565610, 6565611]`.**

## 2. WORKING METHOD (non-negotiable, learned the hard way)

- Workspace `/home/claude/work/chunli`. Shell is **dash** (no bash arrays/process substitution). **mawk** (no `\b` in awk regex).
- Files are mostly **Shift-JIS with CRLF** (chun-li.cns is **LF**; jedah's system-jedah.cns was NEVER valid SJIS — pre-existing mixed encoding, engine loads it fine; don't "fix" it).
- **Inspect** via `iconv -f SHIFT-JIS -t UTF-8//TRANSLIT f > f.u8`. **EDIT bytes via Python latin-1** (round-trips ALL bytes). **Verify** post-edit: `iconv -f SHIFT-JIS -t UTF-8 f >/dev/null`.
- **Stale .u8 caches lie** — re-derive after every edit.
- **Atomic edit scripts**: assert exact anchor text & counts BEFORE writing; on assert-fail nothing is written. When an assert fails, dump the real block text — never guess.
- `/mnt/user-data/outputs` = the staging truth (persists). Container resets; uploads vanish; re-fetch sources from repo.
- Raven's values: surgical reversible byte-edits; never break working chars; revert-as-last-resort; honest accountability (own mistakes plainly — there were several, all recovered).

## 3. THE BENCH UI PROTOCOL (the project's crown jewel)

**Goal**: every author-made bar/meter is visible ONLY while its owner is tagged in, alive, and the round is live. Scales to any future character.

### The three standard blocks (stamp INSIDE each renderer state)

**(A) Spawn gate** — inserted after every `type = Explod` line in the renderer state:
```
triggerall = root,stateno != [6565610, 6565611] && root,alive && roundstate <= 2 ;<-- hidden when benched, KOd, or round over
```

**(B) Sweep** — once per renderer state, right after the statedef header:
```
[State XXXX, Bench UI Sweep]
type = RemoveExplod
trigger1 = root,stateno = [6565610, 6565611]
trigger2 = roundstate > 2
trigger3 = !root,alive
ignorehitpause = 1
```

**(C) Restore** — ONLY for states whose spawns are Time-0/once-fired (no numexplod guards). Re-entering the state resets `time`, re-firing the author's own spawn code:
```
[State XXXX, Bench UI Restore]
type = ChangeState
trigger1 = roundstate <= 2
trigger1 = !(root,stateno = [6565610, 6565611])
trigger1 = root,alive
trigger1 = numexplod(BASE_ID) = 0
trigger1 = time > 1
value = stateno
ignorehitpause = 1
```

### The decision procedure for any NEW character's meter
1. **Find the spawner first** — "the spawner is where the truth lives." Census every `type = Helper` → `stateno = N` in all the char's files (mind casing: `statedef`/`StateDef`/`Statedef` all exist in the roster; use case-insensitive regex).
2. **Check for COMPUTED stateno** (`6100+(var(20)*10)`, `20000+Var(30)*1000`) → per-mode renderer ROOMS. Patch ALL of them. (Missing this caused two full failed iterations.)
3. **Census each renderer state**: explod count, `numexplod` guard count, exits (ChangeState/SelfState).
   - guards ≈ explods → guard-based self-healing → blocks A+B only.
   - guards ≈ 0 → Time-0 once-spawned → blocks A+B+C (find a base explod id always spawned — often `stateno+10` or the first id in slice).
   - exits > 0 → find where the helper migrates; variant rooms (e.g. iori's 24100) need the stamp too. Restore's re-entry re-evaluates config hops automatically.
4. **Check the spawner for DEDUP** (partner,ID comparisons / author-whitelist / fvar flags). If present, in tag every char must host its own:
   `trigger4 = numpartner && teamMode = Tag` inserted before the `id =` line.
5. **WHY removal alone fails**: guard-based templates regenerate removed explods SAME FRAME (remove→respawn at 60hz = pixel-identical "nothing changed"). Spawns MUST be gated at source. Conversely, removal of once-spawned explods without (C) = PERMANENT loss.
6. **Never** put removal in tag.zss / global negative states — it amputates once-spawned bars (the original Iori disaster, reverted).

### Why these conditions
- bench states: tag-out & waiting outside.
- `root,alive`: KO'd char with LoseOnKO=0 lies dead in 5150-family, NEVER benched, round continues → without this, dead chars' bars persist (Chun exposed it; hole existed everywhere).
- `roundstate <= 2` gates + `> 2` sweep: round-end victory walk-ons bring BOTH chars on stage → bars would overlap.

## 4. ROSTER INVENTORY (what was patched where)

| System | File(s) (install path) | Renderer states | Style | Extras |
|---|---|---|---|---|
| CVS groove (kyo/haohmaru/terry/sakura — byte-identical shared file) | `groove.cns` → ALL FOUR folders | 6100,6110,6120,6130,6140,6150,6170 (groove = `6100+var(20)*10`) | guard-based (A+B), 57 gates | GP counter state **6500** also stamped (A+B+**C**, base id 6500; 6501 = empty "display off" room). |
| CVS mains ×4 | `cvsterry/cvskyo/cvshaohmaru/cvssakura.cns` | — | — | Gauge spawner de-dedup (`id = 6100` block) + GP spawner de-dedup (`id = 6500`) + `[State -2, Blocking-12` missing `]` fixed (all 4 had it) + noPowerBarDisplay assert. |
| Iori | `Cvs2_system.cns` (capital C) → Cvs_iori folder | 21000,22000,23000,24000,**24100**(var(52) hop),25000,26000 (= `20000+Var(30)*1000`) | Time-0 (A+B+C, base = stateno+10; 24100 uses 24010) | 121 gates. Spawner de-dedup (`id = 21000`, harsher dedup: higher-ID NEVER hosted). 25050 = S-groove "PowMAX" badge, Time-0, full A+B+C. **Iori has NO GP counter.** noPowerBarDisplay in isys -2. His own `groove.cns` copy is INERT (def doesn't load it). |
| SF3 four (GM author: ryu/gouki/ken/ibuki) | mains `sf3_*.cns`; spawners in `sf3_*-2-3.cns` | **POWER gauge = helper 50000 state 50000 (in MAINS)** — the SA meter. 25000 = STUN gauge (config-gated via helper(30000) var(20)/var(21)). | both guard-based (A+B) | **TRAP: state 25000's comment says スタンゲージ — early patches gated the WRONG meter for days.** fvar(37) = GM-family-partner flag → dedup on BOTH spawners → de-dedup'd (`trigger4` after the fvar(37) trigger3 line, ×2 per -2-3 file). -2-3 files also carry the TAG DAMAGE FIX (teammode=tag added to fvar(26) mercy gates — without it SF3 chars deal 0 damage in tag) + noPowerBarDisplay. Ken/Ibuki's template variant uses a different spawn-prefix anchor than ryu/gouki. |
| Chun-Li (Muteki) | `chun-li.cns` (424KB, **LF**), assert in `chun-li2.cns` | 3999 (shell) + 4000/4001/4002 (segments) — FOUR coexisting helpers | guard-based (A+B), 39 gates | NO dedup (always hosts own). Bar assembly MOVED y 231→225 (−6 on all pos constants incl. satellites at 213/233/242/249) to match SF3 height (`var(17)=225` in ryusys). Fill = segment-swap sprites → bar CANNOT be lengthened without sprite work or scale-stretching. |
| Jedah (rei) | `vampire_system.cns`, assert in `system-jedah.cns` → jedah folder | 8000,8005,8100,8105 (guard-based A+B) + **8751,8761 (Time-0 → A+B+C, base = first id in slice)** | mixed | lowercase `[statedef`. No dedup found. system-jedah was never valid SJIS (pre-existing; harmless). |
| Morrigan (misao) | `Morrigan_F.cns` (renderers), `Morrigan_A.cns` (spawner+config) → `Morrigan/STATE/` subfolder | 17000 (23 explods) + 19000 (6) | guard-based (A+B) | **Author DISABLED her custom DS meter in teams** (`Var(24)` setter had `trigger1 = NumPartner = 0`) — tag re-enable added (`trigger2 = teamMode = Tag`). Her assert is **conditional**: `trigger1 = NumHelper(17000)` so engine bar returns if custom meter absent (adopt this conditional pattern for future fragile chars). ProjHit(800)/(900) → ProjHit800/900 (nightly rejects parens). No dedup. |

**noPowerBarDisplay asserts** (engine bar hidden for custom-meter chars) live in: 4× sf3 -2-3, 4× CVS mains, Cvs2_system, chun-li2, system-jedah, Morrigan_A (conditional). **Exact flag spelling `noPowerBarDisplay` — `noPowerBar` CRASHES the nightly at fight load** (Invalid AssertSpecial flag panic). Sibling flags exist: noFaceDisplay, noNameDisplay, noWinIconDisplay, noStunBarDisplay, noGuardBarDisplay.

## 5. fight.def (engine lifebar) — default power bar relocation

- Lifebar localcoord **1280,720**. Only ONE `[Powerbar]` section (line ~1545) — NO Tag/Simul Powerbar variants exist (unlike Guardbar/Stunbar) → it serves all modes.
- Current: `p1.pos = 614,820` (grows LEFT, range.x −4,−206), `p2.pos = 666,820` (grows RIGHT, mirrored). All 14 elements `scale = 2.35,2.5` (length ≈ SF3's ~484px, height bumped). Counters (1/2/3/Max numbers) offsets rescaled outboard: p1 `-560,28`, p2 `560,28` (offsets are UNSCALED px — scale changes silently strand them mid-bar).
- **CRITICAL LESSON: lifebar sprite axes are invisible in the .def** — the bar SPRITE renders ~157px ABOVE its pos anchor (measured from Raven's screenshot). That's why y=820 > localcoord 720 (not clamped). Chun's move was 1:1 because both endpoints were same-space char explods with readable targets; lifebar moves need screenshot iteration.
- **NEAR-DISASTER AVERTED ONCE**: a regex for `p2.pos` grabbed the [Lifebar] HEALTH bar (line ~94) instead of the Powerbar's — always anchor fight.def edits on the section-local exact values (e.g. `712,83`), never first-match keys. There are MANY mode sections with identical key names.
- Both pos lines carry `TUNE HERE` comments. Screenshot-measured; pillarbox math: game x-area ≈155..1120 px in a 1278-wide shot, scale ≈0.754, y maps 1:1.

## 6. tag.zss CURRENT STATE (14,002 bytes — do not regress)

- Helper invisibility+noShadow while root in [LeavingScreen,WaitingOutside] **with tandem exemption** `root,var(8) != 2` (Jotaro/DIO stands stay visible mid-barrage; redirected `map()` reads return 0 in this build — use var(8) directly).
- Timestop tag-block: `map(ownStop) = 0` added to the tag switch-decision condition (tag DEFERRED during caster's own timestop; AI's choice executes after).
- ALL pin/removeExplod experiments were REVERTED — never move characters or remove explods from the zss.

## 7. OTHER LANDMARKS ALREADY DONE (don't redo)

- **Jotaro/DIO (Warusaki3 HFTF)**: div-by-zero ×55, animelem clamps ×154, stand broadcast maps (standActive/standGauge in -2), voice-stop on bench, timestop engine helpers (jotaro 3210, dio 3210/3610) bench-cleanup, ownStop map trio. Atoi 9999999999 warnings = benign int32 truncation of 10–16-nine pause/supermovetime in gauge spawners (CVS mains, iori isys, HFTF).
- **SF3 0-damage in tag**: fvar(26) mercy cascade only enumerated simul/single/turns → `|| (enemy,teammode = tag)` added to 5 gates per -2-3 (routed to single branch; simul branch reads enemy(1) which tag doesn't enumerate). SA-select helper numpartner gate neutralized.
- **Chun-Li AI v6.5+** (~67 controllers + brain 39000 in chun-li.cmd): parry/punish doctrine, stand-warfare vs HFTF, oki, closer mode. Guard-lock fixed. chun-li2.cns enemy(1) reads guarded `&& numenemy >= 2`.
- **MVC2 Spiderman**: announcer callouts gated off (assets absent), orphan BindToParent ×4 gated `ishelper`, missing snd gated.
- **CVS cmd/cns lint**: iori cmd state-100 trigger order; trigger gap-fillers pattern = insert `triggerN = 0 ;<-- inert gap-filler`.
- **Unclosed `[State -2, Blocking-12` header** existed in ALL FOUR CVS mains (parse damage — their Blocking-12 logic was silently broken until fixed).

## 7.5 HOW THE BAR MYSTERIES WERE ACTUALLY SOLVED (the epistemology — internalize this)

The four bar campaigns (groove, SF3, Darkstalkers, stand bars) were each solved by the same escalation ladder. Future Claude: climb it deliberately instead of rediscovering it.

1. **Trace the spawner before touching any renderer.** Every "no effect" failure traced to patching a room the live entity never occupied: groove's per-groove rooms (`6100+var(20)*10`), Iori's ×1000 stride (`20000+Var(30)*1000` + the 24100 config-hop variant), SF3's two-gauge decoy (state 25000 = STUN gauge; the SA meter = helper/state 50000). Author comments name things truthfully — read them.
2. **Classify spawn style before choosing the medicine.** Guard-based (`!NumExplod` everywhere) → gate the spawns; removal alone is invisible (same-frame regeneration). Once-spawned (Time-0, no guards) → removal is amputation; needs the ChangeState self-restore. Mixed states exist (GP counter) — restore is the universal antidote.
3. **When a correct-looking mechanism silently does nothing, suspect the PIPELINE, then bypass it.** The stand-bar shift failed three times for three stacked reasons: (a) below a DestroySelf = never executed; (b) above the template's own `var = 0` defaults = executed then erased; (c) `partner,map()` = dead (redirected map reads return 0 in this build — a documented lesson I forgot). After exhausting ordering fixes, the winning move was **eliminating the pipeline entirely**: bake the logic into the explods' own pos expressions, evaluated at spawn — nothing to overwrite, no parent chain, no execution order. *When a value must survive hostile/unknown writers, compute it at the point of consumption.*
4. **One disconfirming observation outranks any model.** "Numbers right, bars high" killed the scaling-axis theory in one line (sprite-axis offset is FIXED ~173px, scale-independent; lifebar counter text has its own ~203px delta and does NOT scale with elements). Raven's screenshots-via-repo-commit turned two days of coordinate guessing into one measurement.
5. **Verify execution, not just syntax.** Print line-number proofs (defaults < shift < DestroySelf). A block can be perfectly formed and dead. And verify your own verifier (the grep that matched its own comment).
6. **Authornames are identity in this build**: case-insensitive (`"Warusaki3"` matches `"warusaki3"` checks — proven by J+D). Nimame = polnareff+avdul. Use authorname triggers where maps would be natural but are dead.
7. **Mislabeled constants propagate.** "var(8)=2 = tandem" lived in project memory for weeks; it actually flags AUTONOMOUS STAND SPECIALS (ORAORA 11000, Mach-ORA 11100, Star Finger 11200, GC 11900). Real tandem = the 12xxx state family. One wrong label produced two opposite-looking bugs (Star Finger visible-frozen at stage edge while benched; true tandem invisible). When two bugs are mirror images, suspect one shared misclassification.

## 7.6 HFTF SOUND/TANDEM FIXES (2026-06-11, this session)

- **ORA/MUDA loop-on-interrupt**: two loop sources. (a) ROOT-played loop (jotaro 4513-region: channel 0, `loop=1`, ended only by a later sound in the sequence — interrupted = loop forever). Fix: `[State -2, Voice Loop Failsafe]` StopSnd channel 0 at `movetype = H && time = 0` (once per gethit-state entry; NEVER per-frame channel -1 — that corrupts audio, learned twice). (b) STAND-played loop ([Statedef 11010] both chars; dio also 3653): the stand has `DestroySelf trigger root,movetype = H` — death orphans its channel (sounds outlive dead owners). Fix: StopSnd block at TOP of those states mirroring the DestroySelf's triggers (root/parent movetype=H, parent 12200/12300) — physically above = runs first, same tick.
- **tag.zss visibility exemption** re-keyed: was `root,var(8) != 2` (wrong constant, see 7.5#7); now `!(stateNo in [12000,12999] && root,authorName = "warusaki3")` — keys on the HELPER's own tandem states. Fixes both: Star Finger stand now hides on bench like everything else; true tandem stand stays visible completing its rush while its user is benched.

## 8. DEBUGGING PLAYBOOK (ranked by historical win-rate)

1. **Raven's in-game debug-pause entity readout** ("name's helper, N, M") — decoded the doppelganger, the timestop engines; THE tool when files won't confess. Ask for it whenever an on-screen entity can't be matched to code.
2. **Screenshot via repo commit** + curl + `view` — measured what no .def could tell.
3. **Spawner-first census** (§3 step 1–4). Never patch a renderer before tracing who enters it and whether stateno is computed.
4. "No change + no errors" after a removal patch ⇒ guard-based same-frame respawn. "Worked once then gone forever" ⇒ once-spawned, needs restore. "Both bars vanish on switch" ⇒ dedup'd shared bar, owner benched.
5. Crash log `Invalid AssertSpecial flag` etc. = parse-time vocabulary; check Ikemen GO flag spelling.
6. Author comments are gold: スタンゲージ=stun gauge, パワーゲージ=power gauge, グルーヴ=groove, ゲージ=gauge, 背景=background, 枠=frame; "ここを0にするとOFFにできます"=set 0 to disable.

## 9. OPEN / PENDING

- **fight.def y=820 + scale 2.35,2.5 awaiting Raven's visual confirm** (latest iteration from screenshot math; expect ≤1 more nudge).
- Default engine bar of a KO'd-but-round-continuing char still displays (seen in screenshot for dead Jotaro) — fight.def can't condition per-state; if Raven wants it, add conditional `noPowerBarDisplay` assert (`trigger1 = !alive`) to default-bar chars… (would need per-char edits to HFTF etc.; not requested yet).
- 50000 hosts meter PlaySnd chimes — benched char's meter can chime via PowerShare (cosmetic; gate on request).
- Batch `numenemy >= 2` guards for other muteki-style chars' *2.cns (console-spam class).
- HFTF starting-bar removal option (PowerSet 1000→0, [Statedef 190], dio ~3292 / jotaro ~4262) on request.
- Meter/power tuning (Chun charge rate, Tifa comeback) deferred until tag meta observed.
- Possible future: per-SA power caps vs PowerShare interaction; more roster (each new char = §3 procedure).
- Felicia confirmed: NO custom meter (default bar serves her).

## 10. STAGED FILE SIZES AT HANDOFF (byte-truth for install verification)

tag.zss 14,002 · groove.cns 244,521 · Cvs2_system.cns 214,963 · cvsterry.cns 259,639 · cvskyo.cns 354,091 · cvshaohmaru.cns 327,341 · cvssakura.cns 360,064 · cvs_iori.cmd 123,778 · chun-li.cns 429,958 · chun-li2.cns 27,846 · chun-li.cmd 108,311 · sf3_ryu.cns 108,488 · sf3_gouki.cns 84,310 · sf3_ken.cns 100,512 · sf3_ibuki.cns 114,874 · sf3_ryu-2-3.cns 81,058 · sf3_gouki-2-3.cns 85,948 · sf3_ken-2-3.cns 91,931 · sf3_ibuki-2-3.cns 84,836 · vampire_system.cns ~149,000 · system-jedah.cns 92,617 · Morrigan_F.cns ~(F+~1,800) · Morrigan_A.cns 56,714 · fight.def 93,009 · jotaro.cns 1,225,325 · dio.cns 970,993 · jotaro.cmd 552,131 · dio.cmd 450,666 · MVC2_Spiderman.cns 329,647 · MVC2_Spiderman_-2.cns 9,666 · Cvs2_system old sizes invalid.

*If a size mismatches in-game behavior, suspect a missed install before suspecting the code — that pattern recurred several times.*
