# ultimabrawlers — CHANGELOG (append-only)

Newest at top. **Grep this by subsystem ID; do not read it whole.** Each entry is one shipped change.
Entry format:

```
## [Pnnn] YYYY-MM-DD HH:MM CT — build <tag-or-unknown>
Subsystem: <atlas-id> [/ family or sub-area]
Files shipped: <subfolder/filename>, ...
Change: what was edited, in one or two precise sentences.
Why: the reason / the bug it fixes.
Left untouched: things deliberately not changed + why (gameplay vars, settled chars, etc.).
Test: what Raven should verify.
Status: shipped | awaiting-test | confirmed | reverted. Supersedes: <P-id or none>.
```

Patch IDs are monotonic and never reused. Confirmed/reverted status gets updated in place by editing
the entry's Status line (the only allowed in-place edit; everything else is append-only).

---

> NOTE: P001–P006 are **backfilled** from the handoff doc. Exact dates/times were not recorded, so they
> read "date-unknown (pre-2026-06-16)". Treat them as historical context, not precise audit.

## [P018]  (font baked in - see P018b note in body)
 Font BAKED IN (P018b): chose VT323 (Raven's pick; Silkscreen secondary). Added to [Files]:
font10 = ikemen1/fonts/VT323.ttf + font10.height = 44 (verified via centered-menu mock render vs 54px spacing;
40-48 all readable, 44 chosen). Repointed [Title Info] menu.item.font + menu.item.active.font from 4 to 10.
VT323.ttf must be dropped into data/ikemen1/fonts/. Height is a single tweakable number. To switch to
Silkscreen later: swap the font10 file + maybe height ~32.
 2026-06-16 — menu/logo centered (ikemen1 motif) + pixel font options
File: data/ikemen1/system.def (active motif). Menu was hard-right (menu.pos=1240,330, font align -1).
Centered: menu.pos -> 640,330 (top-left origin, 1280 wide => 640); menu.item.font / menu.item.active.font
align -1 -> 0. Logo (sprites 0,0-0,3 in system.sff, 699x257, centered axis 349) sat at start=-250,155 on the
4 [TitleBG Title Logo*] layers; BG layers use SCREEN-CENTER origin (proof: [AttractBG Title Logo] same sprite
at start=0; negative -250 only makes sense center-relative) so start.x -250 -> 0 centers it; y=155 + sin.y bob
untouched. Two coordinate systems coexist: menu/foreground = top-left (center=640), BG layers = center
(center=0). Fonts: motif declares font1-9 in [Files]; menu uses font4=ikemen1/fonts/Menu1.def. To swap: add
fontN = ikemen1/fonts/<file>.ttf (Ikemen takes TTF/.fnt/.def), set fontN.height, point menu.item.font at N.
Provided pixel TTF options (Silkscreen Bold recommended, Press Start 2P / Silkscreen / VT323) + rendered
preview. Did NOT wire a font into system.def (TTF height needs a visual test pass).

### P017b — cvszcammy default power bar hidden
Cammy showed BOTH her custom groove gauge AND the default engine power bar (+level number). Added the standard
Warusaki3 `[State -2, Hide Engine Power Bar]` AssertSpecial flag=noPowerBarDisplay to cvscammy.cns -2 (Guile
and the roster already have it; her fresh version lacked it). This is the INVERSE of the Gal129/Honda P011 fix
(those chars REMOVE the assert because they use the default bar). Verified her groove gauge spawn (6100) is
untouched - the assert only flips the engine power-bar flag, independent of the custom gauge helper.
## [P017] 2026-06-16 — cvszcammy (Warusaki3) full Warusaki3 treatment
Files: cvszcammy/cvscammy.cns (popups/announcer) + cvszcammy/groove.cns (bench-UI + intro-hide).
New Warusaki3 char (folder cvszcammy, main cns = cvscammy.cns, NOT cvszcammy.cns). Standard groove
architecture (cvs_common + groove.cns + config.txt). Treatment:
  - GP: ALREADY off in her config.txt (var(0) = 2**0 in [State 10000, see GROOVE POINT]) - no action.
  - Popups/announcer: P014 generic patch on cvscammy.cns -> 46 popups + 2 announcer gated (uniform w/ roster).
  - Meter bench-UI + intro-hide: her groove.cns (md5 014ce641) was the PRE-bench-UI version - 0 bench guards,
    meters never hid when benched AND showed during intro. Diff vs roster groove.cns: her file is a STRICT
    SUBSET (0 Cammy-only lines; the 165 missing lines are exactly the bench-UI guards+sweeps). So replaced her
    groove.cns with the finished variant-A groove.cns (grooveA_P015: bench-UI + roundstate=2 intro-hide).
    Verified zero content loss. Her gauge explod-id sequence is byte-identical to variant A's.
LESSON: a freshly-pushed Warusaki3 char may ship the ORIGINAL groove.cns (no bench-UI). Diff vs a known-good
variant; if it's a strict subset, swap in the finished groove.cns rather than hand-adding 165 lines.

## [P016] 2026-06-16 — P014 rolled to 11 groove chars + Iori (H) bespoke popup gate
Files: cvsryu/ken/chunli/zangief/gouki/king/nakoruru/haohmaru/kyo/terry/sakura .cns (popup+announcer, P014
generic patch, uniform 46 popups + 2 announcer each) ; Cvs_iori/Cvs2_system.cns (bespoke).

GROOVE ROLLOUT: the P014 patch (gate -2 helper spawns whose stateno expression contains a 6600-6803 integer,
literal or ifelse, + group-9000 PlaySnds) applied identically to all 11 remaining groove chars. Identical
counts confirm the -2 spawn block is boilerplate across the roster.

IORI (author "H", Family-B): his popups are H's OWN system, NOT the groove 6600-6803 range - they live at
6000-6109 (e.g. COUNTER HIT=6001+var(45)*10, FIRST ATTACK=6002+var(45)*10, BLOCKING/GUARD CANCEL/JUST DEFENDED/
TECH BONUS/Reversal/SPECIAL+SUPER+FINEST finish text) + naration 6800-6803, all spawned in cvs2_system [-2].
That's why his "Counter!" survived the groove patch. FIX: gate -2 helper spawns whose stateno contains a number
in 6000-6109 or 6800-6803. CRITICAL PROTECTIONS (NOT gated): the "Gauge" helper (20000+Var(30)*1000 = the
meter) and the "groove" keyctrl helper (stateno 30000) - gating that keyctrl helper would clone Iori exactly
like the Mai v1 bug. The 8130 "COUNTER HIT EFFECT" (hit spark VFX) is also left (not in range). LEFT ALONE:
the 9000/9010/9020/9030 "finish" helpers - these are the dramatic super-KO CINEMATIC (assert NoBG/NoMusic/NoFG
to darken the screen), not a text bubble; pending Raven's call on whether to also kill that.
GENERAL LESSON: H/Family-B chars use a different popup state range AND carry a keyctrl groove helper in their
own cns -2 - always gate by stateno-range + protect name~groove/keyctrl, never blanket-gate -2 helpers.

## [P015] 2026-06-16 — groove meters hidden until round starts
Files: groove.cns (variant A: guile/ryu/ken/chunli/zangief/gouki/king/nakoruru ; variant B: haohmaru/kyo/
terry/sakura)
The groove EX/super meter (the "gauge" helper, stateno 6100+(var(20)*10), display states 6100/6110/6120/6130/
6140/6150/6160/6170 in groove.cns) was guarded by `roundstate <= 2`, which INCLUDES the intro (roundstate 0/1)
- so the meter showed during the walk-in before FIGHT. Fix: in the 8 gauge states only, create-guards
`roundstate <= 2` -> `roundstate = 2` and the bench sweep `roundstate > 2` -> `roundstate != 2`. Net: meter
visible ONLY during the active fight (roundstate 2); hidden during intro (0/1) AND post-KO (3/4). Bench/KO/dead
hiding preserved (other sweep triggers untouched). GP state 6500 and all non-gauge states verified byte-
identical. groove.cns has 2 variants so 2 files; covers all 12 groove chars. Other meter families (cvs2_system,
SF3, Chun-Li, Jedah, Morrigan) still to be audited for the same intro-hide.

### P014 addendum — computed-stateno popup survivors fixed
First test (Guile): combos/grades gone, but "Counter Hit" (and possibly its voice) survived. CAUSE: the active
Counter Hit spawn uses a COMPUTED stateno `stateno = ifelse(!(var(0)&2**13),6641,6631)` - the first numeric
gate matched only LITERAL statenos, so the 4 ifelse-based spawns slipped through. FIX: gate by ANY 6600-6803
integer appearing in the stateno expression (literal or inside ifelse). Now 46 popup spawns + 2 announcer
gated; all popup-named helpers (Guard/First Attack/Counter Hit/Tech Hit/Reversal/Finish Hit/Complete/Vital/
Perfect/Max Combo/naration) confirmed gated. LESSON: message spawns can carry computed statenos - match by
number-in-expression or by helper name, not literal stateno only.

## [P014] 2026-06-16 — char-side popup + announcer suppression (Guile reference; roster rollout pending)
File shipped: cvsguile/cvsguile.cns  (reference; identical generic patch to roll to other 11 once verified)

The CvS chars spam their OWN combo counter, action messages, grade calls, AND announcer voice over the
engine's native ones. All of it is cosmetic helpers spawned from the MAIN cns `[Statedef -2]`:
  - 6600-6644 : combo / action messages (FIRST ATTACK, COUNTER, etc.)
  - 6700-6764 : additional message family
  - 6800-6803 : grade narration helpers (Fantastic/Great/Finish/Complete) - helper name "naration_N",
                these also PLAY the announcer voice (snd group 10000), so gating them kills grade voice too
  - announcer : root-side PlaySnd snd group 9000 (e.g. [State -2,HyperComboFinish] 9000,0; 9000,4)
FIX (P014): add `triggerall = 0` to each popup helper spawn (42) + each group-9000 PlaySnd (2) in -2.
Pure cosmetic gating - CANNOT affect gameplay or cause a clone (worst case a popup remains). Fully reversible
(remove the triggerall=0 lines). GP (state 6500 spawn) intentionally NOT touched here - handled by config
var(0) bit 0 (P013), kept separate.
NOTE: groove.cns has TWO variants across roster (md5 edb94315 x8: guile/ryu/ken/chunli/zangief/gouki/king/
nakoruru ; e6abe860 x4: haohmaru/kyo/terry/sakura) but the popup SPAWNS live in each char's own cns -2, so the
generic patch (gate helper spawns with stateno in 6600-6644/6700-6799/6800-6803 + 9000 PlaySnds) applies
per-file regardless. Rollout: same programmatic patch to the other 11 cvs*.cns after Raven verifies Guile.

## [P013] 2026-06-16 — GP counter hide (groove roster) + Mai groove-gauge bench fix + announcer/popup recon
Files shipped: config.txt (drop into all 12 groove folders), cvsmai/cvs2_system.cns

GP / Grade-Point counter — HIDE (groove family): the author's switch is var(0) bit 0 ("2**0 = GROOVE POINT
  OFF", documented in config.txt; state 6500 ChangeStates to empty state 6501 when the bit is set). Edited the
  one line in config.txt `[State 10000, see GROOVE POINT]`: `var(0) = 0` -> `var(0) = 2**0`. config.txt is
  BYTE-IDENTICAL (md5 80eff3a4) across all 12 groove chars (cvsguile/haohmaru/kyo/terry/sakura/ryu/ken/chunli/
  zangief/gouki/king/nakoruru), so ONE file covers the roster. NOTE: Haohmaru was NOT actually hidden before —
  his config/groove.cns/cns are identical to Guile's on GP; the whole roster showed it. GP is display-only
  (CvS2 grade score, never consumed) so hiding is cosmetic and safe. Honda's GP is Family-B (cvs2_system,
  different config structure) — deferred to Family-B pass.

Mai (author "H", Family-B cvs2_system, gauge state 21000): her groove gauge had 24 explods and ZERO bench
  handling (showed always). Added the standard kyo/terry bench pattern (Sweep RemoveExplod + Restore
  ChangeState) at the TOP of state 21000, so it hides on tag-out/KO/round-end and re-draws on tag-in. Does NOT
  remove the gauge (the prior fix had deleted it entirely).

Announcer + action popups — RECON (not yet changed): announcer = sound GROUP 9000 (PlaySnd in the main cns,
  e.g. value=9000,0 on WinKo). Action/combo popups = the message-helper family (states 6600-6644 in groove.cns)
  spawned from the MAIN cns `[Statedef -2]` (cvsguile L9867-10350), gated by var(58) bits; with var(58)=0
  (default) only the base set (6600/6602/6603/6604) spawns. Plan: patch ONE char (Guile) as reference - gate
  those base message spawns + the 9000 PlaySnds - have Raven verify, THEN roll to all. Do NOT mass-edit 12
  chars unverified. Open Q for Raven: kill the combo COUNTER (hit number) too, or only action messages?


### P013 addendum — Mai gauge v1 REVERTED (clone) -> v2 (safe)
v1 (Sweep + Restore ChangeState value=21000) caused a Mai CLONE that attacked with its own CPU + console
"invalid state 30000" error. ROOT CAUSE: state 21000 is run by a keyctrl=1 helper named "groove" (id 20000,
home state 30000), gated by a var(30) / Root,Numhelper(20000) handshake. The Restore's ChangeState re-entry
reset that helper's timeline and broke the handshake -> it fell to state 0 as a keyctrl entity (clone).
HARD LESSON: NEVER use a ChangeState/re-entry "restore" on Mai's 21000 (or any state that is itself the
groove-helper/keyctrl machinery). v2 hides the gauge WITHOUT re-entry: each gauge-explod CREATE is gated on
`numexplod(id)=0 && !benched && root,alive && roundstate<=2`, plus a per-id RemoveExplod sweep on bench/KO/
round-end. All runs inside the helper's existing per-tick loop; var(30)/DestroySelf/29000-spawn untouched.
v2 cannot reproduce the clone (no ChangeState). Worst case = behaves like always-on original.


### P011 extension — Honda (Cvs_Honda) normal-meter
Honda is another Gal129 normal-meter char (folder Cvs_Honda, def Cvs_honda.def, uses Cvs2_system.cns). Same
treatment as cvs2_blanka/cvs2_dhalsim: disabled `[State -2, Hide Engine Power Bar]` AssertSpecial
(flag=noPowerBarDisplay) in Cvs2_system.cns L9643 (trigger1 = 1 -> 0) so the default engine power bar shows.
No GP for Honda (per Raven). No custom-gauge plumbing existed on Honda, so nothing to revert.

## [P012] 2026-06-16 23:10 CT — build nightly-06-07-2026
Subsystem: HUD / fight.def [Powerbar]
Files shipped: data/fight.def
Change: normalized every `p{1,2}.front<N>.palfx.sinmul` (front500..front10000 + frontMax) to the base
  `front` value `18, 18, 18, 70`. They previously varied per power threshold (front500=12,12,12,90, etc.).
Why: the power bar is one fill sprite (43,0) with mul=256,256,256; the per-threshold sinmul is a white shimmer
  added over the blue sprite. Lower sinmul = less white = darker/more-saturated blue. At 500 power (half of
  level 0) it switched front->front500 and visibly dropped to a darker blue, staying dark up the levels. Making
  all thresholds match the initial `front` shimmer keeps brightness uniform across the whole fill.
Note: there is a separate `front.palfx.sinmul = 128,128,128,15` in a DIFFERENT bar section (not [Powerbar]) —
  do not confuse it with the powerbar base; scope edits to inside [Powerbar].

## [INVESTIGATION] 2026-06-16 — GP / Grade-Point counter (state 6500)
GP = CvS2 grade/score (var(50)); awards points for win quality (remaining life, combos, perfects, no-damage,
  round wins). It is DISPLAY-ONLY — var(50) is never consumed and gives no combat advantage; purely cosmetic.
Lives in: groove.cns state 6500 (groove family, PER-CHAR copies) + Family-B cvs2_system (Honda/Mai/Iori).
  NOT present in Family-C Gal129 cvs2_blanka/cvs2_dhalsim (no statedef 6500). Display = box (anim 6500/6550),
  "GP" label (6501/6551), digits (explods 6510-6517), near top-center below health bars.
Current state: only BENCH-guarded (shows when active, hides when benched). Checked cvsterry's groove.cns — its
  GP counter is still active-visible, identical to cvsguile's — so despite the note that kyo/terry/etc were
  "hidden", the GP counter itself does NOT appear hard-hidden in those files. Flag to Raven before mass-editing.
To hide fully: set the ~20 GP-display explod `triggerall` to 0 (or comment them) per char's 6500 state; leave
  the score calc (harmless). Low-risk, cosmetic, per-char (groove.cns is not shared).

## [P011] 2026-06-16 22:00 CT — build nightly-06-07-2026
Subsystem: bench-ui-meters / Family C (Gal129) — RESOLUTION + revert of P007-P010
Files shipped: cvs2_blanka/N-cvs2_blanka.cns, cvs2_blanka/cvs2_system.cns,
  cvs2_dhalsim/N-cvs2_dhalsim.cns, cvs2_dhalsim/cvs2_system.cns
THE ANSWER: Gal129's cvs2_blanka/cvs2_dhalsim do NOT have a working custom power meter. The author's blurb
  ("multiple grooves incl. custom EX-mode power bar, integrated Guard bar, integrated CVS2 system") oversells
  it; a FRESH install of the character shows a plain ENGINE power meter. The 8000/8100 intro indicator and the
  8200 gauge family exist in the code but do not render as a usable bar in this game. Every attempt to surface
  the 8200 gauge (P008 un-gate + bench blocks, P009 var(59) guard, P010 groove clamp) was chasing a phantom.
Change: (1) REVERTED P008/P009/P010 — N- 8200 spawn restored to Gal129 original (partner-exclusions intact, no
  clamp/gates); cvs2_system restored to pristine (8200 bench Sweep/DestroySelf blocks removed). (2) Disabled the
  `[State -2, Hide Engine Power Bar]` AssertSpecial (flag=noPowerBarDisplay) in each N- — that P001-era assert
  hid the default engine power bar to make room for a custom bar that never displays. With it off, the normal
  engine power meter shows and the engine handles tag-in/out natively (active char's bar shows, benched char's
  doesn't) — exactly the desired behavior.
Not touched: P007 (st5 intro-indicator arbitration comments) — affects only the never-relevant 8000/8100 intro
  groove display, inert w.r.t. the power bar; left as-is to avoid disturbing prior work.
Lesson: VERIFY a feature actually renders in a fresh install before building meter plumbing for it. An author's
  feature blurb is marketing, not a spec.
Status: shipped — should be the final word on Blanka/Dhalsim meters.

## [P010] 2026-06-16 20:30 CT — build nightly-06-07-2026
Subsystem: bench-ui-meters / Family C (Gal129) — THE fix for "no visible meter" (completes P008/P009)
Files shipped: cvs2_blanka/N-cvs2_blanka.cns, cvs2_dhalsim/N-cvs2_dhalsim.cns
Change: clamped the 8200 gauge-helper spawn stateno to a valid groove:
  `stateno = 8200 + ifelse(var(59)=[0,6], var(59), 0)*10 + (var(59)=6)*5`. Disabled the P009 `var(59)!=-1`
  guard (insufficient — it only caught -1).
ROOT CAUSE (the piece missed in P008/P009): the gauge picks its state by `8200 + var(59)*10`, and in tag
  `var(59)` is copied from the partner via `var(59) = partner,var(20)` (the [State -3] VarSets). **The
  partner's var(20) is NOT a groove index.** In groove.cns it is a reused scratch var that during the match
  holds a GROOVE-POINT DISPLAY COORDINATE — config.txt sets `var(20)=5`, and states 6713/6723 compute
  `var(20)=root,var(47)*5`, `(root,var(47)-9)*3+45`, up to 999. So Blanka copied values like 5/45/999 into
  var(59) -> gauge tried to enter states 8450/8200+9990/etc. that DON'T EXIST -> helper spawned into a dead
  state -> no bar. The original design never hit this because, paired with a meter-partner, the gauge spawn
  was gated OFF entirely (the deference gate removed in P008). Clamping to [0,6] makes the helper always enter
  a real 82xx state (out-of-range -> groove 0). Power display is identical across groove styles, so the bar
  shows and fills correctly; only the groove STYLING defaults to 0 when var(59) is garbage (cosmetic).
Test: Blanka & Dhalsim 2v2 mirror — gauge should finally be VISIBLE when active, hide on tag-out/round-end/KO,
  restore on tag-in.
Status: shipped — awaiting test.

## [P009] 2026-06-16 19:20 CT — build nightly-06-07-2026
Subsystem: bench-ui-meters / Family C (Gal129) — completes P008
Files shipped: cvs2_blanka/N-cvs2_blanka.cns, cvs2_dhalsim/N-cvs2_dhalsim.cns
Change: added `triggerall = var(59) != -1` to the 8200 gauge-helper spawn in `[Statedef -2]`.
Why: P008 un-gated the 8200 spawn but the meter still didn't show — a TIMING bug it exposed. `var(59)`
  (groove index; selects the gauge state via `stateno = 8200 + var(59)*10`) is computed at frame 0 from
  scratch var(1) and DEFAULTS TO -1 (var(1)=0 -> var(1)%6=0 -> -1). It only becomes valid (0-5) when copied
  from the partner at roundstate=2 (the [State -3] VarSets). The un-gated spawn fired during intro
  (roundstate=1, fvar(37)=1 branch) while var(59) was still -1 -> tried to enter **state 8190, which does not
  exist** (8200-8265 exist, 8190 does not) -> dead helper that took id 8200 and blocked respawn -> no bar.
  Guarding on `var(59) != -1` defers the spawn until the groove is valid (roundstate=2, post partner-copy),
  so it always enters a real 82xx state. Order-independent (re-checks each tick).
Left untouched: everything else from P008; the partner-groove copy (it's what provides a valid var(59) in
  tag — so Blanka's gauge currently shows the PARTNER's groove styling; see watch item).
Test: Blanka & Dhalsim 2v2 mirror — gauge should now appear at fight start when active, hide on tag-out /
  round-end / KO, restore on tag-in.
Status: shipped — awaiting test. Supersedes: none (completes P008).

## [P008] 2026-06-16 18:30 CT — build nightly-06-07-2026
Subsystem: bench-ui-meters / Family C (Gal129 CvS2-EX: cvs2_blanka, cvs2_dhalsim)
Files shipped: cvs2_blanka/N-cvs2_blanka.cns, cvs2_blanka/cvs2_system.cns,
  cvs2_dhalsim/N-cvs2_dhalsim.cns, cvs2_dhalsim/cvs2_system.cns
Change: (1) In `[Statedef -2]` (N-cvs2_<c>.cns), un-gated the **8200** gauge-helper spawn — commented the 4
  partner-exclusion `trigger2` lines so it spawns regardless of partner — and added `triggerall = stateno !=
  [6565610,6565611]` so it does NOT respawn while the root is benched. (2) In cvs2_system.cns, added a bench
  block (RemoveExplod sweep + DestroySelf, on root benched / roundstate>2 / !root,alive) to the TOP of all 8
  in-match gauge states (8200/8210/8220/8230/8240/8250/8260/8265), which previously had NO bench handling.
Why: **CORRECTION to the Family-C model.** The real in-match power meter is the **8200 family in
  cvs2_system.cns**, NOT 8000/8100. States 8000 & 8100-8160 both DestroySelf at roundstate>1 — they are the
  INTRO groove-selector/indicator, gone the instant the fight starts. The 8200 gauge's spawn was blocked by
  the same `!(partner has a meter)` gate, so in any tag team with a meter-partner (e.g. + Guile) the fight
  meter never spawned -> "no meter at all." 8200 also had zero teardown, so it needed bench handling added.
Left untouched: 8200 gameplay/power-read logic; 8098/8099 selector; Family A/B; single-play (root never
  benches, so the meter only hides at round-end/KO there — matches protocol).
Test: Blanka & Dhalsim in 2v2 (incl. mirror Blanka+Guile vs Guile+Blanka): fight meter now (a) appears when
  active regardless of pick order/partner, (b) hides on tag-out, (c) hides at round start/end + victory,
  (d) restores on tag-in.
Status: shipped — awaiting test. Supersedes: corrects the "8100-8160 = in-match meter" claim in P004/P007.
Note on P007: P007 commented the simul-arbitration in 8000/8100-8160 (the intro indicator). Harmless but it
  was the wrong target; it never touched the fight meter. Left in place (benign).

## [P007] 2026-06-16 CT — build: repo main (anevilwizardcat-gif/ultimabrawlers)
Subsystem: bench-ui-meters / Family C (Gal129 EX-meter, cvs2_blanka + cvs2_dhalsim)
Files shipped: cvs2_blanka/system-cvs2_blanka.cns, cvs2_dhalsim/system-cvs2_dhalsim.cns
Change: commented out the leftover MUGEN-simul bar arbitration in the in-match EX-meter display
  states (8000 and 8100-8160). In each state's RemoveExplod AND DestroySelf, disabled the
  trigger pair `triggerN = numpartner` + `triggerN = (partner,authorname="warusaki3"&&partner,fvar(39)=1)
  ||(root,ID-partner,ID>0 && (partner rei/gal129)&&partner,fvar(39)=1)`. 16 pairs (32 lines) per char.
Why: that pair is "if my teammate also has a meter, suppress/share mine" — correct for MUGEN simul
  (one shared on-screen bar) but wrong for this 2v2 TAG game where only one teammate is on screen and
  the bench UI already hides the benched meter. It was the only pick-order/partner-dependent thing in
  the meter path, matching Blanka's symptom (picked 1st w/ another meter char = invisible; picked 2nd =
  always visible even when benched).
How (mechanism): `fvar(39)` = system-type flag (1 = CvS2 meter). The arbitration keyed off the
  teammate's author + fvar(39). Removing it makes Blanka/Dhalsim always own their own meter; visibility
  is then decided solely by the already-present bench Sweep+Guard (root,stateno bench check).
Left untouched: the bench Sweep/Guard (kept, 9 sweeps + 39 guards intact per file); the pre-round groove
  SELECTOR states 8098/8099 and their ID arbitration (transient, dies at roundstate=2, only fires vs
  rei/gal129 partners); cvs2_system.cns (shared + overridden by st5; gameplay logic — NOT touched);
  all gameplay states. Statedef counts unchanged (blanka 70, dhalsim 56).
Test: (1) CVS Blanka picked FIRST alongside a groove char (e.g. Guile) -> his meter should now show when
  he's tagged in and hide when benched. (2) CVS Blanka picked SECOND -> meter should now HIDE when benched
  (not stay up). (3) Same for CVS Dhalsim. (4) Sanity: a Blanka+Dhalsim team (two Family-C chars) -> each
  should show own meter when active, hide when benched.
Status: shipped, awaiting-test. Supersedes: none (extends P004 which added the bench hide to these files).
Confidence note: high that this removes the pick-order dependence; if "benched but visible" still occurs
  for either char after this, that points to a bench-guard gap on a specific explod rather than the
  arbitration -> send a screenshot of which bar lingers and I'll chase that explod id next.

## [P006] date-unknown (pre-2026-06-16) — build unknown
Subsystem: stand-system / data/tag.zss
Files shipped: data/tag.zss
Change: added one-line exemption `(map(ownStop)=0 || map(ownTandem)=1)` to the Jotaro tandem tag-in gate
so tandem is allowed while standalone timestop super stays blocked. `ownTandem = (var(8)=2)`.
Why: switch gate was blocked whenever `map(ownStop)=1`, which covered the whole internal-timestop tandem.
Left untouched: standalone timestop block (still gated).
Test: Jotaro can tag during tandem; timestop super still can't tag.
Status: shipped. Supersedes: none. Note: could extend to DIO/Polnareff/Avdul if they broadcast ownTandem.

## [P005] date-unknown (pre-2026-06-16) — build unknown
Subsystem: bench-ui-meters / Family B
Files shipped: Cvs_Honda/Cvs2_system.cns, cvsmai/cvs2_system.cns
Change: commented `trigger1 = ID<partner,ID` above `id = 21000` so each char spawns its own gauge.
Why: tag needs per-char meter; the lower-ID arbitration suppressed one teammate (2 Hondas = 0 bars).
Left untouched: `var(30)=1` Turns-Mode block, `fvar(1)` team-position VarSets (gameplay).
Test: 2 Hondas same team → both show a bar when active; benched one hides.
Status: shipped. Supersedes: none.

## [P004] date-unknown (pre-2026-06-16) — build unknown
Subsystem: bench-ui-meters / Family C
Files shipped: cvs2_blanka/system-cvs2_blanka.cns, cvs2_dhalsim/system-cvs2_dhalsim.cns
Change: applied bench sweep+guard pattern to EX-gauge states 8000/8100–8160/8526 in each char's own system file.
Why: the shared-file sweep never touches the author's bolted-on EX gauge in `system-cvs2_<c>.cns`.
Left untouched: id-21000 gauge spawn (Blanka/Dhalsim don't use it).
Test: benched Blanka/Dhalsim EX gauge disappears; restores on tag-in.
Status: shipped. Supersedes: none.

## [P003] date-unknown (pre-2026-06-16) — build unknown
Subsystem: bench-ui-meters / Family A
Files shipped: chars/groove.cns (shared — covers all 12 groove chars)
Change: added sweep+guard to gauge state 6160 (EX/MAX-mode draw) — the one display state that lacked a sweep.
Why: EX/MAX gauge stayed drawn while benched.
Left untouched: gameplay states; only the 6100–6170 gauge band.
Test: benched groove char in EX/MAX shows no lingering gauge.
Status: shipped. Supersedes: none.

## [P002] date-unknown (pre-2026-06-16) — build unknown
Subsystem: bench-ui-meters / Family A
Files shipped: <each groove char>/<char>.cns (×12: 8 Group-A + kyo/terry/sakura/haohmaru)
Change: commented the single `!partner,authorname = "warusaki3"` exclusion line in all three spawn blocks
(6000/6500/6100) per char.
Why: two Warusaki3 teammates → only first-pick spawned a meter; second pick got nothing.
Left untouched: spawn logic otherwise; gameplay.
Test: two groove chars same team → each spawns its own meter; benched one hides.
Status: shipped. Supersedes: none.

## [P001] date-unknown (pre-2026-06-16) — build unknown
Subsystem: bench-ui-meters / default engine power bar
Files shipped: <groove + cvs2 roster>/<char main with winning -2>
Change: added `noPowerBarDisplay` AssertSpecial to the winning `[Statedef -2]` across the groove roster + cvs2 family.
Why: default engine power bar was leaking through on groove chars that use a custom meter.
Left untouched: custom meter logic.
Test: no default engine power bar on groove/cvs2 chars.
Status: shipped. Supersedes: none.

## [P018c] Menu items invisible -> revert to bitmap font (TTF not rendered by build)
SYMPTOM: after P018b, main-menu logo centered fine but menu CHOICES invisible; cursor sounds
still play (menu logic + position OK, only glyph drawing fails). DIAGNOSIS: menu.item.font was
pointed at font10 = VT323 (FNT v2 Type=truetype). This build does not draw TrueType to screen --
consistent with Raven's own observation that the motif's Open_Sans (also truetype .def) is shipped
but never visibly used. The author made BITMAP fonts (Menu1.def + Menu1.sff, indexed 8-bank) for all
visible UI for this reason. FIX (surgical, centering preserved): menu.item.font + menu.item.active.font
reverted 10 -> 4 (original Menu1 bitmap), align kept 0 (center), menu.pos kept 640,330. font10 VT323.def
line commented (parked). NEXT: to get the VT323 LOOK, must render VT323 into a .sff bitmap glyph sheet +
bitmap .def matching Menu1 format (fixed size; active-color via palette bank or RGB tint). TTF wrapper
route abandoned for this build. HARD LESSON: in this motif, custom UI fonts MUST be bitmap .def+.sff;
truetype .def loads without error but renders nothing.

## [P018d] Menu font -> Pixel (bitmap, renders in this build)
Raven picked "Pixel" from a rendered comparison of the motif's existing bitmap fonts (Menu1/Menu2/Pixel/
PixelFlat), as the closest guaranteed-render match to the VT323 look. Font already shipped in motif
(font2 = ikemen1/fonts/Pixel.def + Pixel.sff) -> NO new font files needed. system.def changes only:
menu.item.font 4->2, menu.item.active.font 4->2 (bank 0, active blue tint 123,206,255 preserved),
menu.item.spacing 0,54 -> 0,30 (Pixel native height 18px vs Menu1 42px). menu.pos kept 640,330 (centered).
Tweakables: spacing 2nd number = line gap; pos.y = vertical start. NOTE for future: bitmap fonts are
fixed-size; to enlarge Pixel "Smash-thick" would require a 2x nearest-neighbor re-rendered Pixel.sff
(offered, Raven chose native size). FONT GLYPH FORMAT (hard-won, for any future bitmap font work):
SFFv2, group 0, image = ASCII code; sprites are fmt=12 PNG32 in ldata block, each preceded by a
4-BYTE LENGTH PREFIX -> PNG signature starts at (ldata_off + node.data_offset + 4). Header: 0x24=node
array off, 0x28=sprite count, 0x34=ldata off. Node=28B: +2 item(ascii), +16 data_off(u32), +20 data_len(u32).

## [P018e] Menu highlight -> gold; select-screen title -> Pixel
menu.item.active.font RGB 123,206,255 (blue) -> 255,210,40 (gold/yellow). [Select Info] title.font
4,0,0 -> 2,0,0 (was font4 Menu1 = the OLD main-menu font; now Pixel to match P018d). Tweak gold via the
RGB triplet. NOTE: select-screen NAMES/stage/record/teammenu still on font3 (Menu2) - a different
secondary font, left as-is (can switch to Pixel on request).
BACKGROUNDS (reported, NOT changed - baked sprites): main-menu blue = [TitleBG Background Sky] spriteno
100,0; char-select red = [SelectBG Background Sky] spriteno 101,0; both inside data/ikemen1/system.sff.
Recolor requires editing the sprite (Fighter Factory) or a programmatic extract->hue-shift->reinject
into the SFFv2 (risky on the 8MB sff; do with preview + care). Not a .def edit.

## [P019] Dante_KOF round-start clone — DIAGNOSED, fix needs missing file (OPEN)
Char CNS work (separate from P018* motif/font). Clone = helper ID 90900 spawned (Dante.cns [Statedef -2])
into Stateno 90900, which is undefined in all loaded files -> falls to state 0 -> visible clone, no AI.
Console "Dante's helper (59)" -> 59 is runtime index, gameplay ID is 90900. Root cause: def references
st4=misc.cns + stcommon=common1.cns, BOTH 404 in repo; misc.cns is Wou's system-states file holding
[Statedef 90900] (+ 90901/90902/99996/99997/99998/195500). Other repo Dantes are different authors
(R@CE AKIR@; Alexlexus/Zeckle/WanteD) -> cannot donate Wou's system. FIX: re-add Wou's misc.cns (+common1.cns)
to chars/Dante_KOF/. Interim option: stub an inert [Statedef 90900] to suppress clone. See cards/Dante_KOF.md.

## [P019 RESOLVED] Dante_KOF clone — fixed via inert statedef 90900 stub
Correction: Misc.cns IS pushed (capital M; raw is case-sensitive, my lowercase probe 404'd - logged as a
fetch lesson). Re-verified: statedef 90900 referenced ~20x, defined 0x across all 6 loaded files (Misc.cns
included) - the ADD004 system genuinely isn't in this variant. FIX: appended inert [Statedef 90900] stub to
Dante.cns (invisible, intangible, no vars set, no DestroySelf) -> helper lands in a valid inert state, clone
gone, var(22) unchanged (already 0). Reversible; remove if real ADD004 system restored. LATENT: def st4=misc.cns
vs file Misc.cns = Windows-OK but Linux/Steam-Deck-breaking casing mismatch (one-line def fix offered).
Full JD/style/bar still dormant pending Wou's original system file.

## [P020] Dante_KOF - Dante - S.cns trigger6 gaps fixed
States 1405/1420 PlaySnd: triggers [1-5,7,8] -> renumbered to [1-7] so the skipped swing sounds fire. Only 2
gap blocks in all his files. Shipped Dante - S.cns.
## [P020b] Dante_KOF - explod anim 4472 missing (OPEN)
[Statedef -2] persistent Explod ID 4472 anim=4472 not in Dante.air -> invalid-action warning, invisible effect.
Missing asset; offered to gate it or take the correct anim. Not changed yet.
## [P021] Wolverine - throw/jump clone fixed (missing jump-dust state 8100)
ADD004 engine "Jump Dust" helper run in char state 8100, which was undefined (had 8200 land-dust, not 8100)
-> state-0 clone. Added [Statedef 8100] mirroring 8200 + existing anim 8100 -> clone gone, jump dust restored.
Minor: sounds 5000,11 / 40,0 missing (silent, harmless). See cards/Wolverine.md.

## [P022] Dante_KOF - guard spark/sound spam fixed (42/6,2 absent from ultimabrawlers fightfx)
HitDef guard.sparkno=42 -> 40 (std guard spark, exists in data/fightfx.air); guardsound=6,2 -> 6,0 (only 6,0
exists in data/common.snd). Swept N/S/H.cns + Misc.cns (21 + 17). Real fix, not mute. Verified fightfx actions
[0,1,2,3,10,11,12,40,60..130] and common.snd groups [5,6,7,20]/g6 idx [0].
## [P022b OPEN] hit sparkno=6 also absent from fightfx -> will warn on hit; remap pending Raven's spark choice.

## [P023 DECISION NEEDED] Dante_KOF - whole effect layer needs ADD004 fightfx (not installed)
"Each attack warns" = systemic: 83 explods + hit/guard sparks reference ADD004 fightfx absent from
ultimabrawlers' minimal data/fightfx.air. Options: (A) mute-all sweep (gate 83 explods + remap sparks; plain
look, clean console, reversible) or (B) install ADD004 fightfx (restores effects; global file, riskier).
Awaiting Raven. Folds in earlier P020b (4472 explod) + P022b (sparkno 6) as part of the same root cause.

## [P023 DONE] Dante_KOF - effect layer reconciled to ultimabrawlers' default fightfx
Raven: ADD004 route or default fx for damage hits. ADD004 fightfx not installable (3rd-party + global risk),
so: hit sparks 4/5/6/8 -> 2 (40x), guard 41/42 -> 40 (48x), and 83 decorative explods with absent anims gated
(triggerall=0). Result: every hit/block shows a proper default spark+sound; no console spam; no on-screen loss
(gated effects were already invisible); fully reversible. Closes P020b (4472) + P022b (sparkno 6). 6 files shipped.

## [P024 DONE] Dante_KOF - sound refs reconciled (F6,1 / F9000,0 / 1000,3 etc.)
Invalid hitsound->5,0, guardsound->6,0; stray F-prefixes stripped to local (F9000,0->9000,0); bad local idx
remapped (1000,3->1000,0); missing voice/effect PlaySnds gated. EnvColor RGB values correctly ignored.
0 live invalid sounds left. 6 files shipped.

## [P025] Menu - select-screen fonts -> Pixel + gold highlights
[Select Info]: p1.name.font 3->2 + colour 210,210,255(blue)->255,210,40(gold); p2.name.font 3->2 (pink kept);
stage.font 3->2; stage.active.font 3->2 +gold; title already 2 (P018e). 6 refs. NOTE: the select CURSOR box
(the actual selection highlight) is sprite anim 160/161 (p1) & 170/171 (p2) in system.sff - a sprite recolor,
not a .def value. Menu sprite map: title bg 100,0; menu logo 0,0-0,3; select bg 101,0; cell bg 150,0 - all in
data/ikemen1/system.sff. Active lifebar = data/fight.def (motif system.def [Files] fight = fight.def).

## [P026] Menu - team-menu fonts, stage flicker, name sizes, P2 colour
Stage-name FLICKER root cause: stage.active2.font (the active blink colour) was still font3 - active stage
blinked between Pixel-gold (active.font) and Menu2 (active2.font). Fixed: stage.active2.font + stage.done.font
-> font2. Team-mode text ("Single"/"Tag" = teammenu.item.font; "TEAM MODE" = teammenu.selftitle/enemytitle)
p1+p2 -> font2 (p1 gold, p2 cyan); teammenu title scale .75->1 for Pixel. P2 name/teammenu colour 255,210,239
(pink) -> 90,225,255 (cyan) to contrast gold+purple (NOTE: p2 colour is independent of p1, always was).
Larger text: added p1.name.scale/p2.name.scale/stage.scale = 1.4,1.4 (Ikemen text elements take .scale, e.g.
teammenu titles already did - if names/stage don't grow in-engine, fallback = build a 2x Pixel bitmap font).
Extracted bg sprites from system.sff -> menu_sprites/: menu bg (100,0), charselect bg (101,0), logo (0,0), all
PNG32 1280x960 / 699x257. Backgrounds are NOT loose files; they live inside data/ikemen1/system.sff.

## [P027] Menu/Select background REMIX - purple Persona-pixel + scrolling starfields (system.sff rebuilt)
From-scratch redesign (not a recolour). Replaced 7 sprites inside data/ikemen1/system.sff:
  100,0 menu bg (1280x960)   - purple dithered gradient, gold halftone burst (top-right), gold diagonal
                               accent lines, clean star outlines, sparse pixel symbols, scanlines.
  101,0 select bg (1280x960) - same language, darker/more saturated, GOLD accent (per Raven; was cyan),
                               halftone bottom-left.
  100,1 (1280x960), 100,2 (2559x782), 100,3 (2467x960), 101,2 (2559x782), 101,3 (2467x960)
                             - transparent seamless STARFIELDS replacing the cloud scroll layers.
                               Mostly-transparent stars/diamonds/plus, wrap-seamless on X (drew each star
                               at x, x-W, x+W) so tile=1,0 loops cleanly R->L. Two densities = parallax
                               (slow faint back .2 layer / fast bright front .3 layer).
Kept each sprite at its EXACT original WxH so the existing [TitleBG]/[SelectBG] start/tile/velocity config
applies unchanged - NO system.def edit needed for the bg swap.
SFF REBUILD METHOD (verified): SFFv2, all data in ldata (tdata empty), 258 nodes @1360, ldata @8584.
PNG sprite ldata entry = uint32(W*H*4 uncompressed size) + PNG bytes; dataLength = 4 + len(png) (the 4-byte
prefix is the RAW size, NOT png length - confirmed 100,0 prefix 4915200 = 1280*960*4). 22 linked sprites
(fmt1/len0) preserved verbatim (resolve via linked-index, offset ignored). Rebuilt ldata in node order,
patched each node dataOffset/Length + header ldata_len/tdata_off. VERIFIED: 235 PNG decode ok, 1 LZ5 intact,
22 links valid, 0 failures, all 7 targets decode at native dims. New file 5.85MB (was 8.04MB; my PNGs
compress better). Editable source PNGs also shipped in menu_sprites/.

## [P028] FIX scroll layers - restore 100,1 (my error) + visible star LATTICE
Two issues from P027, found via full [TitleBGdef]/[SelectBGdef] re-read:
 (1) MY ERROR: replaced sprite 100,1 = "Background Black Bars" (static, trans=add1, NO velocity/tile,
     reused in BOTH TitleBG + SelectBG) with a starfield. 100,1 is a static additive UI overlay, NOT a
     panning cloud. -> RESTORED 100,1 to original (rebuilt from clean /tmp/system.sff; confirmed byte-identical).
 (2) The genuine panning layers ARE 100,2/100,3 (menu) + 101,2/101,3 (select) [tile=1,0, vel -0.1 back /
     -0.7 front]. P027 filled them with a UNIFORM RANDOM starfield -> pans but reads as static (no distinct
     feature to track motion). FIX: regenerated as a REGULAR DIAGONAL STAR LATTICE (even spacing, distinct
     bright star/sparkle/diamond stamps, brighter alpha) -> drift is now clearly visible + satisfying.
     Back layer dim/small (spacing150 sc4), front bright/big (spacing128 sc6) = parallax. Seamless on X
     (N=round(W/spacing) exact cells, wrap copies at x,x-W,x+W).
Rebuilt system.sff (now 6 sprites: 100,0 menu bg, 101,0 select bg, 100,2/3 + 101,2/3 lattices; 100,1 + all
others verbatim). VERIFIED: 235 PNG decode, 22 links valid, 0 fail, 100,1 byte-identical to original.
Shipped NEW_scroll_DEMO.gif (parallax loop preview) + lattice source PNGs in menu_sprites/.
LESSON: a sprite being in the cloud sprite-group (100,x) does NOT mean it's a scrolling layer - check the
.def element it's bound to (velocity/tile) before replacing. 100,1 = static bars; only x,2 and x,3 scroll.

